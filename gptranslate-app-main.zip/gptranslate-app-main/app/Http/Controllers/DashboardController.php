<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Translation;

class DashboardController extends Controller
{
    public function stats(Request $request)
    {
        $shop = session('shop');

        $totalTranslations = Translation::where('shop', $shop)->count();
        $lastTranslationAt = Translation::where('shop', $shop)->latest()->value('created_at');

        return response()->json([
            'totalTranslations' => $totalTranslations,
            'lastTranslationAt' => $lastTranslationAt,
        ]);
    }
}
