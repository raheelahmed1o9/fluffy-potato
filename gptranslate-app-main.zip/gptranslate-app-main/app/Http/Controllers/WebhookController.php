<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage; // 👈 Add this!
use App\Models\Shop;
use App\Models\Translation;

class WebhookController extends Controller
{
    public function handle(Request $request)
    {
        // Verify HMAC signature
        $hmacHeader = $request->header('X-Shopify-Hmac-Sha256');
        $calculatedHmac = base64_encode(hash_hmac('sha256', $request->getContent(), config('services.shopify.client_secret'), true));

        if (!hash_equals($hmacHeader, $calculatedHmac)) {
            return response('Invalid HMAC signature', 401);
        }

        $topic = $request->header('X-Shopify-Topic');
        $shopDomain = $request->header('X-Shopify-Shop-Domain');

        if ($topic === 'app/uninstalled') {
            Log::info('App uninstalled by ' . $shopDomain);

            // Delete merchant-related data
            Shop::where('shopify_domain', $shopDomain)->delete();
            Translation::where('shop', $shopDomain)->delete();
            Storage::disk('local')->delete("settings/{$shopDomain}.json"); // 👈 Delete settings file

            return response('Webhook handled: app uninstalled', 200);
        }

        return response('No action taken', 200);
    }
}
