<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use App\Models\Translation;
use App\Models\Shop;

class GDPRController extends Controller
{
    public function customerDataRequest(Request $request)
    {
        Log::info('GDPR customer data request', ['payload' => $request->all()]);

        return response('Received customer data request', 200);
    }

    public function customerRedact(Request $request)
    {
        Log::info('GDPR customer redact request', ['payload' => $request->all()]);

        return response('Received customer redact request', 200);
    }

    public function shopRedact(Request $request)
    {
        Log::info('GDPR shop redact request', ['payload' => $request->all()]);

        $shopDomain = $request->input('shop_domain');
        if ($shopDomain) {
            Shop::where('shopify_domain', $shopDomain)->delete();
            Translation::where('shop', $shopDomain)->delete();
            Storage::disk('local')->delete("settings/{$shopDomain}.json");
        }

        return response('Received shop redact request', 200);
    }
}
