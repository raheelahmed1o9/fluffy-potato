<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Models\Translation;

class TranslationController extends Controller
{
    // ✅ Get all translations (optionally filtered by locale)
    public function index(Request $request)
    {
        $locale = $request->query('locale');

        $translations = $locale
            ? Translation::where('locale', $locale)->get()
            : Translation::all();

        return response()->json($translations);
    }

    // ✅ Store a new translation
    public function store(Request $request)
    {
        $validated = $request->validate([
            'key' => 'required|string',
            'value' => 'required|string',
            'locale' => 'required|string',
        ]);

        $translation = Translation::create($validated);
        return response()->json($translation, 201);
    }

    // ✅ Update a translation
    public function update(Request $request, $id)
    {
        $translation = Translation::findOrFail($id);

        $validated = $request->validate([
            'key' => 'required|string',
            'value' => 'required|string',
            'locale' => 'sometimes|string',
        ]);

        $translation->update($validated);
        return response()->json($translation);
    }

    // ✅ Delete a translation
    public function destroy($id)
    {
        $translation = Translation::findOrFail($id);
        $translation->delete();

        return response()->json(['message' => 'Translation deleted']);
    }

        // ✅ Auto-translate using selected engine (default: ChatGPT)
        public function autoTranslate(Request $request)
        {
            $request->validate([
                'key' => 'required|string',
                'engine' => 'sometimes|string|in:chatgpt,google,deepl',
            ]);

            $key = $request->key;
            $engine = $request->engine ?? 'chatgpt';

            if ($engine === 'chatgpt') {
                $prompt = "Translate this text to another language: \"{$key}\"";

                $response = Http::withToken(env('OPENAI_API_KEY'))->post('https://api.openai.com/v1/chat/completions', [
                    'model' => 'gpt-3.5-turbo',
                    'messages' => [
                        ['role' => 'system', 'content' => 'You are a helpful translation assistant.'],
                        ['role' => 'user', 'content' => $prompt],
                    ],
                ]);

                if (!$response->successful()) {
                    return response()->json(['error' => 'OpenAI translation failed'], 500);
                }

                $translated = $response['choices'][0]['message']['content'] ?? '...';
                return response()->json(['translated' => trim($translated)]);
            }

            if ($engine === 'google') {
                return response()->json(['translated' => '[Google Translate not yet implemented]']);
            }

            if ($engine === 'deepl') {
                return response()->json(['translated' => '[DeepL not yet implemented]']);
            }

            return response()->json(['error' => 'Invalid engine'], 400);
        }

}
