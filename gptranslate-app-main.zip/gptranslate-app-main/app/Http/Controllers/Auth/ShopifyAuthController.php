<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Laravel\Socialite\Facades\Socialite;
use App\Services\ShopifyProvider;
use Illuminate\Http\Request;

class ShopifyAuthController extends Controller
{
    public function redirect(Request $request)
    {
        $shop = $request->get('shop') ?? session('shop');
    
        \Log::info('OAuth Redirect Request', [
            'shop_param' => $request->get('shop'),
            'session_shop' => session('shop'),
        ]);
    
        if (! $shop || !preg_match('/^[a-zA-Z0-9\-]+\.myshopify\.com$/', $shop)) {
            return response("Missing or invalid 'shop' parameter", 400);
        }
    
        // ✅ Save shop to session early!
        session(['shop' => $shop]);
    
        // Escape iframe if needed
        if (! session('shopify_top_level_oauth')) {
            return redirect()->route('auth.toplevel', ['shop' => $shop]);
        }
    
        // Build the OAuth request
        $config = config('services.shopify');
        $config['redirect'] = url('/auth/callback');
        $config['scopes'] = [
            'read_products',
            'read_content',
            'read_translations',
            'write_translations',
            'read_locales',
        ];
    
        return Socialite::buildProvider(\App\Services\ShopifyProvider::class, $config)
            ->with(['shop' => $shop])
            ->redirect();
    }      

    public function callback()
    {
        try {
            $shopifyUser = Socialite::driver('shopify')->user();
    
            $shop = \App\Models\Shop::updateOrCreate(
                ['shopify_domain' => $shopifyUser->getName()],
                [
                    'shopify_id' => $shopifyUser->getId(),
                    'email' => $shopifyUser->getEmail(),
                    'access_token' => $shopifyUser->token,
                ]
            );
    
            session(['shop' => $shop->shopify_domain]);
    
            // 🆕 REGISTER APP/UNINSTALLED WEBHOOK HERE
            $webhookResponse = \Illuminate\Support\Facades\Http::withHeaders([
                'X-Shopify-Access-Token' => $shop->access_token,
            ])->post("https://{$shop->shopify_domain}/admin/api/2023-04/webhooks.json", [
                'webhook' => [
                    'topic' => 'app/uninstalled',
                    'address' => config('app.url') . '/api/webhooks',
                    'format' => 'json',
                ],
            ]);
    
            if (!$webhookResponse->ok()) {
                \Log::error('Failed to register app/uninstalled webhook', [
                    'shop' => $shop->shopify_domain,
                    'response' => $webhookResponse->body(),
                ]);
            }
    
            // ✅ Redirect back to the embedded app in Shopify Admin
            $clientId = config('services.shopify.client_id');
            return redirect()->away("https://{$shop->shopify_domain}/admin/apps/{$clientId}");
        } catch (\Exception $e) {
            \Log::error('Shopify OAuth Error: ' . $e->getMessage());
    
            return redirect('/auth')->withErrors([
                'error' => 'Authentication failed. Please try again.',
            ]);            
        }
    }     
    
    public function topLevel(Request $request)
    {
        $shop = $request->get('shop');

        if (! $shop || !preg_match('/^[a-zA-Z0-9\-]+\.myshopify\.com$/', $shop)) {
            return response("Missing or invalid 'shop' parameter", 400);
        }

        // Mark that we're now operating outside the iframe
        session(['shopify_top_level_oauth' => true]);

        return response()->view('shopify.auth.toplevel', compact('shop'));
    }

 }

