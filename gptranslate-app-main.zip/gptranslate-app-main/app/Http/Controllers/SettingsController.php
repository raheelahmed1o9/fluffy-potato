<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SettingsController extends Controller
{
    protected string $disk = 'local';
    protected string $folder = 'settings';

    // GET /api/settings
    public function show(Request $request)
    {
        $shop = session('shop'); // Assuming you store 'shop' in session during login
        $path = "{$this->folder}/{$shop}.json";

        if (!Storage::disk($this->disk)->exists($path)) {
            // Default settings if no file yet
            return response()->json([
                'defaultLocale' => 'en',
                'defaultEngine' => 'chatgpt',
                'autoTranslateEnabled' => true,
            ]);
        }

        $contents = Storage::disk($this->disk)->get($path);
        return response()->json(json_decode($contents, true));
    }

    // POST /api/settings
    public function save(Request $request)
    {
        $shop = session('shop');
        $path = "{$this->folder}/{$shop}.json";

        $data = $request->validate([
            'defaultLocale' => 'required|string',
            'defaultEngine' => 'required|string',
            'autoTranslateEnabled' => 'required|boolean',
        ]);

        // Ensure the folder exists
        Storage::disk($this->disk)->makeDirectory($this->folder);

        Storage::disk($this->disk)->put($path, json_encode($data, JSON_PRETTY_PRINT));

        return response()->json(['success' => true]);
    }
}
