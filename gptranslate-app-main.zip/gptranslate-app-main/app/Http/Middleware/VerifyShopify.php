<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class VerifyShopify
{
    public function handle(Request $request, Closure $next): Response
    {
        // 👇 Allow all in local environment (for testing)
        if (app()->environment('local')) {
            return $next($request);
        }

        // 👇 Check if shop is authenticated via session
        if (!session('shop')) {
            return response()->json([
                'message' => 'Unauthorized: No shop session found.',
            ], 401);
        }

        return $next($request);
    }
}
