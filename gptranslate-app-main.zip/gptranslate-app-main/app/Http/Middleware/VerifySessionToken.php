<?php

namespace App\Http\Middleware;

use Closure;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Illuminate\Http\Request;

class VerifySessionToken
{
    public function handle(Request $request, Closure $next)
    {
        // 1) Grab the “Authorization: Bearer <token>” header
        $auth = $request->header('Authorization', '');
        if (! preg_match('/Bearer\s+(.+)/', $auth, $matches)) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        $token = $matches[1];

        try {
            // 2) Decode & verify using your Shopify client secret
            $decoded = JWT::decode(
                $token,
                new Key(config('services.shopify.client_secret'), 'HS256')
            );
        } catch (\Exception $e) {
            return response()->json(['error' => 'Invalid token: ' . $e->getMessage()], 401);
        }

        // (Optional) Attach shop origin to the request:
        // $request->attributes->set('shop', $decoded->dest);

        return $next($request);
    }
}
