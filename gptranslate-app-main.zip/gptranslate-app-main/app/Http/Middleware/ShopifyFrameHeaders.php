<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ShopifyFrameHeaders
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $response = $next($request);
    
        if ($request->has('embedded') && $request->get('embedded') === '1' && $request->has('shop')) {
            $shopDomain = $request->get('shop');
    
            $response->headers->set(
                'Content-Security-Policy',
                "frame-ancestors https://{$shopDomain} https://admin.shopify.com;"
            );
        }
    
        return $response;
    }    
}
