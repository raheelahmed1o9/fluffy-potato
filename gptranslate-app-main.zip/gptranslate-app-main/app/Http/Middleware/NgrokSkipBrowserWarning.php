<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class NgrokSkipBrowserWarning
{
    public function handle(Request $request, Closure $next): Response
    {
        // Add it to the request so it reaches Ngrok as early as possible
        $request->headers->set('ngrok-skip-browser-warning', 'true');

        $response = $next($request);

        // Also add to the response
        $response->headers->set('ngrok-skip-browser-warning', 'true');

        return $response;
    }
}
