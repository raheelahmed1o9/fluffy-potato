<?php

namespace App\Services;

use Shopify\Clients\Rest;

class ShopifyApiService
{
    protected $client;

    public function __construct($shopDomain, $accessToken)
    {
        $this->client = new Rest($shopDomain, $accessToken);
    }

    public function getProducts()
    {
        $response = $this->client->get('products');
        return $response->getDecodedBody()['products'] ?? [];
    }

    public function getLocales()
    {
        $response = $this->client->get('locales');
        return $response->getDecodedBody()['locales'] ?? [];
    }

    public function getTranslations($locale, $resourceType, $resourceId)
    {
        $response = $this->client->get('translations', [
            'locale' => $locale,
            'resource_type' => $resourceType,
            'resource_id' => $resourceId,
        ]);

        return $response->getDecodedBody()['translations'] ?? [];
    }
}
