<?php

namespace App\Services;

use Illuminate\Support\Arr;
use Laravel\Socialite\Two\AbstractProvider;
use Laravel\Socialite\Two\User;

class ShopifyProvider extends AbstractProvider
{
    protected $scopes = ['read_products'];
    
    public function user()
    {
        $query = request()->query();
        $hmac = $query['hmac'] ?? '';
        unset($query['hmac'], $query['signature']);
    
        ksort($query);

        $encoded = collect($query)
            ->map(function ($value, $key) {
                return "$key=$value";
            })
            ->implode('&');
        
        $computedHmac = hash_hmac('sha256', $encoded, config('services.shopify.client_secret'));        
    
        if (!hash_equals($hmac, $computedHmac)) {
            abort(403, 'Invalid HMAC signature');
        }
    
        return parent::user();
    }
    
    protected function getAuthUrl($state)
    {
        $shop = $this->parameters['shop'] ?? null;
    
        if (! $shop) {
            throw new \InvalidArgumentException('Missing shop parameter.');
        }
    
        $this->with(['grant_options[]' => 'per-user']);
    
        return "https://{$shop}/admin/oauth/authorize?" . http_build_query($this->getCodeFields($state));
    }
    
    protected function getTokenUrl()
    {
        $shop = $this->parameters['shop'] ?? null;
    
        if (! $shop) {
            throw new \InvalidArgumentException('Missing shop parameter.');
        }
    
        return "https://{$shop}/admin/oauth/access_token";
    }    

    protected function getUserByToken($token)
    {
        $shop = request('shop');

        $response = $this->getHttpClient()->get("https://{$shop}/admin/api/2023-10/shop.json", [
            'headers' => [
                'X-Shopify-Access-Token' => $token,
            ],
        ]);

        return json_decode($response->getBody(), true)['shop'];
    }

    protected function mapUserToObject(array $user)
    {
        return (new User())->setRaw($user)->map([
            'id' => $user['id'],
            'nickname' => null,
            'name' => $user['name'],
            'email' => $user['email'],
            'avatar' => null,
        ]);
    }

    protected function getTokenFields($code)
    {
        return array_merge(parent::getTokenFields($code), [
            'grant_type' => 'authorization_code',
        ]);
    }
}
