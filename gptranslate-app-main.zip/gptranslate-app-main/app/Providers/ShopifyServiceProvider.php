<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Laravel\Socialite\Facades\Socialite;
use App\Services\ShopifyProvider;

class ShopifyServiceProvider extends ServiceProvider
{
    public function boot()
    {
        Socialite::extend('shopify', function ($app) {
            $config = $app['config']['services.shopify'];
            return Socialite::buildProvider(ShopifyProvider::class, $config);
        });
    }

    public function register()
    {
        //
    }
}
