<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Shop extends Model
{
    protected $fillable = [
        'shopify_domain',
        'name',
        'email',
        'access_token',
    ];
}
