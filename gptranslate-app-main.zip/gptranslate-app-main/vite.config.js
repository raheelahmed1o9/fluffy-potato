import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import tailwindcss from '@tailwindcss/vite';
import mkcert from 'vite-plugin-mkcert';
import path from 'path';

// Replace with your actual Ngrok domain
const NGROK_HOST = 'da63-102-89-82-66.ngrok-free.app';

export default defineConfig({
  plugins: [
    laravel({
      input: ['resources/css/app.css', 'frontend/src/main.tsx'],
      publicDirectory: 'public',
      refresh: true,
    }),
    tailwindcss(),
    mkcert(),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'frontend/src'),
    },
  },
  server: {
    host: '0.0.0.0', // Listen on all local interfaces
    port: 5173,
    https: true,
    origin: `https://${NGROK_HOST}`, // Public URL for script injection
    hmr: {
      protocol: 'wss',
      host: NGROK_HOST, // Client connects back here
      clientPort: 443,   // Standard HTTPS port
    },
    watch: {
      usePolling: true,
    },
  },
});
