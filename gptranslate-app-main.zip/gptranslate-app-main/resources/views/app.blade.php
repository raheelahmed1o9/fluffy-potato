<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>GPTranslate App</title>

  @viteReactRefresh
  @vite('frontend/src/main.tsx')

  <script>
    window.apiKey = "{{ env('SHOPIFY_API_KEY') }}";
    window.shopOrigin = "{{ request('shop') }}";
  </script>
</head>
<body>
  <div id="root"></div>
</body>
</html>
