<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>GPTranslate App Dashboard</title>
</head>
<body>
    <h1>Welcome to the GPTranslate App Dashboard 🎉</h1>
    <p>You have successfully authenticated with your Shopify store.</p>

    <h2>Available Store Locales:</h2>
    @if (!empty($locales))
        <ul>
            @foreach ($locales as $locale)
                <li>
                    <strong>{{ $locale['locale'] }}</strong> — {{ $locale['name'] }}
                    @if ($locale['primary']) <em>(Primary)</em> @endif
                </li>
            @endforeach
        </ul>
    @else
        <p>No locales found.</p>
    @endif

    <h2>Sample Product:</h2>
    @if (!empty($products))
        <p><strong>Name:</strong> {{ $products[0]['title'] }}</p>
        <p><strong>ID:</strong> {{ $products[0]['id'] }}</p>
    @else
        <p>No products found.</p>
    @endif

    <h2>French Translations (fr):</h2>
    @if (!empty($translations))
        <ul>
            @foreach ($translations as $translation)
                <li>
                    <strong>{{ $translation['key'] }}</strong>: {{ $translation['value'] }}
                </li>
            @endforeach
        </ul>
    @else
        <p>No French translations found for this product.</p>
    @endif
</body>
</html>
