<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Redirecting…</title>
  <script type="text/javascript">
    // If we’re inside Shopify Admin’s iframe, break out to top-level:
    const redirectUrl = "{{ route('auth.redirect', ['shop' => $shop]) }}";
    if (window.top !== window.self) {
      window.top.location.href = redirectUrl;
    } else {
      window.location.href = redirectUrl;
    }
  </script>
</head>
<body>
  <p>Redirecting to Shopify…</p>
</body>
</html>
