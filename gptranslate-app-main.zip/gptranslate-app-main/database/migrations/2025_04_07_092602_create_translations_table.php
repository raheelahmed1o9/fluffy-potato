<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('translations', function (Blueprint $table) {
            $table->id();
            $table->string('language');     // e.g., 'en', 'fr', 'es'
            $table->string('key');          // unique identifier for the string (like 'homepage.title')
            $table->text('value');          // the translated text
            $table->timestamps();
            
            $table->unique(['language', 'key']); // ensure one translation per language+key
        });
    }
    

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('translations');
    }
};
