import { Modal } from "@shopify/polaris";
import {
  TextField,
  Button,
  Card,
  Page,
  Layout,
  Text,
  Spinner,
  BlockStack,
  InlineStack,
  Toast,
  Box,
  Select,
  Checkbox,
} from "@shopify/polaris";
import LayoutWrapper from "../components/LayoutWrapper";
import { DeleteIcon, EditIcon } from "@shopify/polaris-icons";
import { useAuthenticatedFetch } from "../hooks/useAuthenticatedFetch";
import { useEffect, useState } from "react";

type Translation = {
  id: number;
  key: string;
  value: string;
  locale: string;
};

const locales = [
  { label: "English", value: "en" },
  { label: "French", value: "fr" },
  { label: "Spanish", value: "es" },
  { label: "German", value: "de" },
];

const engineOptions = [
  { label: "ChatGPT", value: "chatgpt" },
  { label: "Google Translate", value: "google" },
  { label: "DeepL", value: "deepl" },
];

const getSeoHint = (key: string) => {
  if (!key) return "";
  if (/\s/.test(key)) return "Avoid spaces in keys. Use dot notation like homepage.title";
  if (!/^[a-z0-9.]+$/.test(key)) return "Use only lowercase letters, numbers, and dots";
  if (!key.includes(".")) return "Use dot notation, e.g., homepage.title";
  return "Looks good!";
};

const getTextStats = (text: string) => {
  const wordCount = text.trim().split(/\s+/).filter(Boolean).length;
  const charCount = text.length;
  let warning = "";
  if (charCount > 150) {
    warning = "This translation is quite long. Consider shortening it for better readability.";
  }
  return { wordCount, charCount, warning };
};
export default function Translations() {
  const fetchWithAuth = useAuthenticatedFetch();

  const [translations, setTranslations] = useState<Translation[]>([]);
  const [filterStatus, setFilterStatus] = useState("all");
  const [loading, setLoading] = useState(true);
  const [selectedLocale, setSelectedLocale] = useState("en");
  const [selectedEngine, setSelectedEngine] = useState("chatgpt");
  const [keyInput, setKeyInput] = useState("");
  const [valueInput, setValueInput] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [toastMessage, setToastMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const [editingId, setEditingId] = useState<number | null>(null);
  const [editKey, setEditKey] = useState("");
  const [editValue, setEditValue] = useState("");
  const [seoHint, setSeoHint] = useState("");
  const [textStats, setTextStats] = useState({ wordCount: 0, charCount: 0, warning: "" });
  const [isSaving, setIsSaving] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(""), 3000);
  };

  const fetchTranslations = async () => {
    try {
      const res = await fetchWithAuth(`/api/translations?locale=${selectedLocale}`);
      if (!res?.ok) throw new Error("Failed to fetch translations");
      const data: Translation[] = await res.json();
      setTranslations(data);
    } catch (err) {
      console.error("Failed to fetch translations", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTranslations();
  }, [selectedLocale]);
  const handleSave = async () => {
    if (!keyInput.trim() || !valueInput.trim()) {
      showToast("Key and value cannot be empty");
      return;
    }

    setIsSaving(true);

    try {
      const res = await fetchWithAuth("/api/translations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: keyInput, value: valueInput, locale: selectedLocale }),
      });

      if (!res?.ok) throw new Error("Failed to save translation");

      const newTranslation = await res.json();
      setTranslations((prev) => [...prev, newTranslation]);
      setKeyInput("");
      setValueInput("");
      showToast("Translation saved");
      setSuccessMessage("Translation saved successfully!");
    } catch (err) {
      console.error("Error saving translation", err);
      showToast("Failed to save translation");
    } finally {
      setIsSaving(false);
    }
  };

  const handleUpdate = async (id: number) => {
    if (!editKey.trim() || !editValue.trim()) {
      showToast("Key and value cannot be empty");
      return;
    }

    try {
      const res = await fetchWithAuth(`/api/translations/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: editKey, value: editValue, locale: selectedLocale }),
      });

      if (!res?.ok) throw new Error("Failed to update");

      const updated = await res.json();
      setTranslations((prev) => prev.map((t) => (t.id === id ? updated : t)));
      setEditingId(null);
      showToast("Translation updated");
      setSuccessMessage("Translation updated successfully!");
    } catch (err) {
      console.error("Error updating translation", err);
      showToast("Failed to update translation");
    }
  };

  const handleDelete = async (id: number) => {
    try {
      const res = await fetchWithAuth(`/api/translations/${id}`, { method: "DELETE" });
      if (!res?.ok) throw new Error("Failed to delete");
      setTranslations((prev) => prev.filter((t) => t.id !== id));
      showToast("Translation deleted");
      setSuccessMessage("Translation deleted successfully!");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      console.error("Error deleting translation", err);
      showToast("Failed to delete translation");
    }
  };

  const handleBulkDelete = async () => {
    try {
      await Promise.all(
        selectedIds.map((id) =>
          fetchWithAuth(`/api/translations/${id}`, { method: "DELETE" })
        )
      );
      setTranslations((prev) => prev.filter((t) => !selectedIds.includes(t.id)));
      setSelectedIds([]);
      showToast("Selected translations deleted");
      setSuccessMessage("Selected translations deleted successfully!");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      console.error("Bulk delete failed", err);
      showToast("Failed to delete selected translations");
    }
  };

  const handleAutoTranslate = async () => {
    try {
      const res = await fetchWithAuth("/api/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: keyInput, engine: selectedEngine }),
      });

      if (!res?.ok) throw new Error("Failed to auto-translate");

      const data = await res.json();
      setValueInput(data.translated);
      showToast("Translation generated");
    } catch (err) {
      console.error("Auto-translate failed", err);
      showToast("Auto-translate failed");
    }
  };
  const filteredTranslations = translations.filter((t) => {
    const matchesSearch =
      t.key.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.value.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesFilter =
      filterStatus === "all"
        ? true
        : filterStatus === "completed"
        ? t.value.trim() !== ""
        : t.value.trim() === "";

    return matchesSearch && matchesFilter;
  });

  const allSelected = filteredTranslations.length > 0 &&
    filteredTranslations.every((t) => selectedIds.includes(t.id));

  return (
    <LayoutWrapper>
      <Page title="Translations Manager">
      {successMessage && (
        <Box paddingBlockEnd="400">
          <Card>
            <BlockStack gap="200">
              <Text as="h2" variant="headingMd" tone="success">
                {successMessage}
              </Text>
              <Button onClick={() => setSuccessMessage(null)} size="slim" variant="secondary">
                Dismiss
              </Button>
            </BlockStack>
          </Card>
        </Box>
      )}
      {showConfirmModal && (
          <Modal
            open={showConfirmModal}
            onClose={() => setShowConfirmModal(false)}
            title="Delete Translation"
            primaryAction={{
              content: "Delete",
              onAction: () => {
                if (confirmDeleteId !== null) {
                  handleDelete(confirmDeleteId);
                }
                setShowConfirmModal(false);
              },
              destructive: true,
            }}
            secondaryActions={[
              {
                content: "Cancel",
                onAction: () => setShowConfirmModal(false),
              },
            ]}
          >
            <Modal.Section>
              <Text as="p">
                Are you sure you want to delete this translation?
              </Text>
            </Modal.Section>
          </Modal>
        )}
        <Layout>

          {/* Translation Form Section */}
          <Layout.Section>
            <Card>
              <Box padding="400">
                <BlockStack gap="400">
                  <Text variant="headingLg" as="h2">🌍 Add Translation</Text>
                  <Text as="p" tone="subdued">Add a key-value translation and select the locale.</Text>

                  <BlockStack gap="300">
                    <Select label="Locale" options={locales} value={selectedLocale} onChange={setSelectedLocale} />
                    <TextField
                      label="Translation Key"
                      value={keyInput}
                      onChange={(value) => {
                        setKeyInput(value);
                        setSeoHint(getSeoHint(value));
                      }}
                      autoComplete="off"
                    />
                    {seoHint && (
                      <Text as="p" tone={seoHint === "Looks good!" ? "success" : "caution"}>
                        {seoHint}
                      </Text>
                    )}
                    <TextField
                      label="Translated Value"
                      value={valueInput}
                      onChange={(value) => {
                        setValueInput(value);
                        setTextStats(getTextStats(value));
                      }}
                      autoComplete="off"
                    />
                    {textStats.warning && (
                      <Text as="p" tone="caution">⚠️ {textStats.warning}</Text>
                    )}
                    <Select label="Engine" options={engineOptions} value={selectedEngine} onChange={setSelectedEngine} />
                  </BlockStack>

                  <InlineStack gap="300" wrap>
                    <Button variant="primary" onClick={handleSave} loading={isSaving}>💾 Save</Button>
                    <Button variant="secondary" onClick={handleAutoTranslate} disabled={!keyInput.trim()}>🤖 Auto-Translate</Button>
                  </InlineStack>

                </BlockStack>
              </Box>
            </Card>
          </Layout.Section>

          {/* Translations List Section */}
          <Layout.Section>
            <Card>
              <Box padding="400">
                <BlockStack gap="300">
                  <Text variant="headingLg" as="h2">Translations</Text>
                  <Select
                    label="Filter"
                    options={[
                      { label: "All", value: "all" },
                      { label: "Completed", value: "completed" },
                      { label: "Missing", value: "missing" },
                    ]}
                    value={filterStatus}
                    onChange={setFilterStatus}
                  />
                  <TextField
                    label="Search"
                    value={searchTerm}
                    onChange={setSearchTerm}
                    autoComplete="off"
                  />

                  {loading ? (
                    <Spinner accessibilityLabel="Loading translations" size="large" />
                  ) : (
                                          <>
                      {filteredTranslations.length === 0 ? (
                        <Box padding="400">
                          <Card>
                            <BlockStack gap="300" align="center">
                              <Text variant="headingLg" as="h2">
                                📄 No Translations Found
                              </Text>
                              <Text as="p" tone="subdued">
                                Start by adding your first translation for this locale.
                              </Text>
                              <Button
                                variant="primary"
                                onClick={() => {
                                  // Scroll back up to the “Add Translation” form
                                  document
                                    .getElementById('add-translation-form')
                                    ?.scrollIntoView({ behavior: 'smooth' });
                                }}
                              >
                                ➕ Add Translation
                              </Button>
                            </BlockStack>
                          </Card>
                        </Box>
                      ) : (
                        <>
                          <Checkbox
                            label="Select All"
                            checked={allSelected}
                            onChange={(checked) => {
                              setSelectedIds(
                                checked ? filteredTranslations.map((t) => t.id) : []
                              );
                            }}
                          />

                          <BlockStack gap="300">
                            {filteredTranslations.map((t) => (
                              <InlineStack key={t.id} align="space-between" blockAlign="center">
                                <InlineStack gap="300" blockAlign="center">
                                  <Checkbox
                                    label=""
                                    checked={selectedIds.includes(t.id)}
                                    onChange={(checked) => {
                                      setSelectedIds((prev) =>
                                        checked ? [...prev, t.id] : prev.filter((id) => id !== t.id)
                                      );
                                    }}
                                  />
                                  {editingId === t.id ? (
                                    <BlockStack gap="100">
                                      <TextField label="Key" value={editKey} onChange={setEditKey} autoComplete="off" />
                                      <TextField label="Value" value={editValue} onChange={setEditValue} autoComplete="off" />
                                      <InlineStack gap="100">
                                        <Button size="slim" onClick={() => handleUpdate(t.id)} variant="primary">Save</Button>
                                        <Button size="slim" onClick={() => setEditingId(null)} variant="tertiary">Cancel</Button>
                                      </InlineStack>
                                    </BlockStack>
                                  ) : (
                                    <Text as="p"><strong>{t.key}</strong>: {t.value}</Text>
                                  )}
                                </InlineStack>

                                {editingId !== t.id && (
                                  <InlineStack gap="100">
                                    <Button icon={EditIcon} onClick={() => { setEditingId(t.id); setEditKey(t.key); setEditValue(t.value); }} />
                                    <Button
                                        icon={DeleteIcon}
                                        onClick={() => {
                                          setConfirmDeleteId(t.id);
                                          setShowConfirmModal(true);
                                        }}
                                      />
                                  </InlineStack>
                                )}
                              </InlineStack>
                            ))}
                          </BlockStack>

                          {selectedIds.length > 0 && (
                            <Button tone="critical" variant="primary" onClick={handleBulkDelete}>
                              Delete Selected
                            </Button>
                          )}
                        </>
                      )}
                    </>
                  )}
                </BlockStack>
              </Box>
            </Card>
          </Layout.Section>

        </Layout>

        {toastMessage && (
          <Toast content={toastMessage} onDismiss={() => setToastMessage("")} />
        )}
      </Page>
    </LayoutWrapper>
  );
}
