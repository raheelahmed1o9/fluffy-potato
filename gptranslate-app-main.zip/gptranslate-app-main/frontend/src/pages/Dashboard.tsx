import { useEffect, useState } from 'react';
import { Page, Card, TextContainer, Spinner, Text } from '@shopify/polaris';
import { useAuthenticatedFetch } from '../hooks/useAuthenticatedFetch';

interface DashboardData {
  totalTranslations: number;
  lastTranslationAt: string;
}

export default function Dashboard() {
  const fetchWithAuth = useAuthenticatedFetch();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchWithAuth('/api/dashboard')
      .then((res) => {
        if (!res) throw new Error('No response from server');
        if (!res.ok) throw new Error(`Error ${res.status}`);
        return res.json() as Promise<DashboardData>;
      })
      .then((json) => setData(json))
      .catch((e: Error) => setError(e.message))
      .finally(() => setLoading(false));
  }, [fetchWithAuth]);

  return (
    <Page title="Dashboard">
      {loading && <Spinner accessibilityLabel="Loading dashboard" size="large" />}

      {error && (
        <Text as="p" variant="bodyMd" tone="critical">
          {error}
        </Text>
      )}

      {data && (
        <Card>
          <TextContainer>
            <p><strong>Total translations:</strong> {data.totalTranslations}</p>
            <p><strong>Last translated at:</strong> {new Date(data.lastTranslationAt).toLocaleString()}</p>
          </TextContainer>
        </Card>
      )}
    </Page>
  );
}
