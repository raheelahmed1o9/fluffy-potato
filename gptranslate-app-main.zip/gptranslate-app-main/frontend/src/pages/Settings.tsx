import {
  Page,
  Layout,
  Card,
  Select,
  Checkbox,
  Button,
  BlockStack,
  Text,
  Box,
  Toast,
} from "@shopify/polaris";
import { useState, useEffect } from "react";
import { useAuthenticatedFetch } from '../hooks/useAuthenticatedFetch';
import LayoutWrapper from "../components/LayoutWrapper";

const locales = [
  { label: "English", value: "en" },
  { label: "French", value: "fr" },
  { label: "Spanish", value: "es" },
  { label: "German", value: "de" },
];

const engineOptions = [
  { label: "ChatGPT", value: "chatgpt" },
  { label: "Google Translate", value: "google" },
  { label: "DeepL", value: "deepl" },
];

export default function Settings() {
  const fetchWithAuth = useAuthenticatedFetch();
  const [defaultLocale, setDefaultLocale] = useState("en");
  const [defaultEngine, setDefaultEngine] = useState("chatgpt");
  const [autoTranslateEnabled, setAutoTranslateEnabled] = useState(true);
  const [toastMessage, setToastMessage] = useState("");
  
  useEffect(() => {
    async function loadSettings() {
      try {
        const res = await fetchWithAuth('/api/settings');
        if (!res || !res.ok) throw new Error("Failed to fetch settings");
  
        const data = await res.json();
        setDefaultLocale(data.defaultLocale);
        setDefaultEngine(data.defaultEngine);
        setAutoTranslateEnabled(data.autoTranslateEnabled);
      } catch (err) {
        console.error("Error loading settings:", err);
      }
    }
  
    loadSettings();
  }, [fetchWithAuth]);

  const handleSaveSettings = async () => {
    try {
      const res = await fetchWithAuth('/api/settings', {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: JSON.stringify({
          defaultLocale,
          defaultEngine,
          autoTranslateEnabled,
        }),
      });
  
      if (!res || !res.ok) throw new Error("Failed to save settings");
  
      setToastMessage("Settings saved successfully!");
      setTimeout(() => setToastMessage(""), 3000);
    } catch (err) {
      console.error("Error saving settings:", err);
      setToastMessage("Failed to save settings");
      setTimeout(() => setToastMessage(""), 3000);
    }
  };  

  return (
    <LayoutWrapper>
      <Page title="App Settings">
        <Layout>
          <Layout.Section>
            <Card>
              <Box padding="400">
                <BlockStack gap="400">
                  <Text variant="headingLg" as="h2">⚙️ App Settings</Text>

                  <Select
                    label="Default Locale"
                    options={locales}
                    value={defaultLocale}
                    onChange={setDefaultLocale}
                  />

                  <Select
                    label="Default Translation Engine"
                    options={engineOptions}
                    value={defaultEngine}
                    onChange={setDefaultEngine}
                  />

                  <Checkbox
                    label="Enable Auto-Translation"
                    checked={autoTranslateEnabled}
                    onChange={setAutoTranslateEnabled}
                  />

                  <Button variant="primary" onClick={handleSaveSettings}>
                    Save Settings
                  </Button>
                </BlockStack>
              </Box>
            </Card>
          </Layout.Section>
        </Layout>

        {toastMessage && (
          <Toast content={toastMessage} onDismiss={() => setToastMessage("")} />
        )}
      </Page>
    </LayoutWrapper>
  );
}
