// frontend/src/hooks/useAuthenticatedFetch.ts
import { useCallback } from 'react';
import { useAppBridge } from '@shopify/app-bridge-react';
import { getSessionToken } from '@shopify/app-bridge-utils';

export function useAuthenticatedFetch() {
  const app = useAppBridge();

  return useCallback(
    async (uri: RequestInfo, init: RequestInit = {}) => {
      // 1) Generate a short-lived JWT for this shop/session
      const token = await getSessionToken(app);

      // 2) Build headers (omit cookies)
      const headers = new Headers(init.headers);
      headers.set('Authorization', `Bearer ${token}`);
      headers.set('Content-Type', 'application/json');

      // 3) Fire your request to the same origin (Laravel API)
      const response = await fetch(uri, {
        ...init,
        headers,
        credentials: 'omit', 
      });

      return response;
    },
    [app]
  );
}
