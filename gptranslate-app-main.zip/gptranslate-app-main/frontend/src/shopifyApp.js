import createApp from '@shopify/app-bridge';
import {authenticatedFetch} from '@shopify/app-bridge-utils';

const shopOrigin = new URLSearchParams(window.location.search).get('shop');

const app = createApp({
  apiKey: import.meta.env.VITE_SHOPIFY_API_KEY,
  shopOrigin,
  forceRedirect: true,
});

export const fetchWithSessionToken = authenticatedFetch(app);
export default app;
