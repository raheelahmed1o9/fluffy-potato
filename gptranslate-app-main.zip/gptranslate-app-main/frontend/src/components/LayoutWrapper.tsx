import { ReactNode } from 'react';
import { Frame, Navigation } from '@shopify/polaris';
import { HomeIcon, GlobeIcon, SettingsIcon } from '@shopify/polaris-icons'; // 🆕 import icons
import { useLocation, useNavigate } from 'react-router-dom'; // 🆕 import navigate

export default function LayoutWrapper({ children }: { children: ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate(); // 🆕

  const navItems = [
    {
      label: 'Dashboard',
      icon: HomeIcon,
      url: '/',
      selected: location.pathname === '/',
      onClick: () => navigate('/'),
    },
    {
      label: 'Translations',
      icon: GlobeIcon,
      url: '/translations',
      selected: location.pathname === '/translations',
      onClick: () => navigate('/translations'),
    },
    {
      label: 'Settings',
      icon: SettingsIcon,
      url: '/settings',
      selected: location.pathname === '/settings',
      onClick: () => navigate('/settings'),
    },
  ];

  return (
    <Frame
      navigation={
        <Navigation location={location.pathname}>
          <Navigation.Section items={navItems} />
        </Navigation>
      }
    >
      <div style={{ padding: '1.5rem' }}>
        {children}
      </div>
    </Frame>
  );
}
