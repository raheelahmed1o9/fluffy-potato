import { Routes, Route, Navigate } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Translations from "./pages/Translations";
import Settings from "./pages/Settings";
import LayoutWrapper from "./components/LayoutWrapper";

export default function App() {
  return (
    <LayoutWrapper>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/translations" element={<Translations />} />
        <Route path="/settings" element={<Settings />} />
        {/* Redirect unknown routes to Dashboard */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </LayoutWrapper>
  );
}
