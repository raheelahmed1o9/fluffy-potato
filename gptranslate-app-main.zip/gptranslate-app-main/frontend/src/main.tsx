import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { Provider } from "@shopify/app-bridge-react";
import { AppProvider as PolarisProvider } from "@shopify/polaris";
import en from "@shopify/polaris/locales/en.json";
import { HashRouter } from "react-router-dom";

const hostParam = new URLSearchParams(window.location.search).get("host");

if (!hostParam) {
  document.body.innerHTML = `
    <div style="font-family: sans-serif; padding: 2rem; text-align: center;">
      <h2>Missing Shopify Host</h2>
      <p>This app must be loaded from the Shopify Admin to work properly.</p>
      <p>Please go back to <a href="https://admin.shopify.com/store/jextensions-store/apps">Shopify Admin</a> and open the app from there.</p>
    </div>
  `;
  throw new Error("Missing host parameter");
}

const appBridgeConfig = {
  apiKey: import.meta.env.VITE_SHOPIFY_API_KEY!,
  host: hostParam,
  forceRedirect: true,
};

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <HashRouter>
      <Provider config={appBridgeConfig}>
        <PolarisProvider i18n={en}>
          <App />
        </PolarisProvider>
      </Provider>
    </HashRouter>
  </React.StrictMode>
);
