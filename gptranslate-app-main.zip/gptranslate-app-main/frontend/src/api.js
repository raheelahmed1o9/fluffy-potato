// frontend/src/api.js

import { fetchWithSessionToken } from './shopifyApp';

/**
 * Fetch current shop info from Laravel
 */
export async function getShopInfo() {
  // 🔑 Use fetchWithSessionToken instead of window.fetch
  const response = await fetchWithSessionToken('/api/shop');
  if (!response.ok) {
    throw new Error(`API error: ${response.status}`);
  }
  return response.json();
}

/**
 * Fetch translations list
 */
export async function listTranslations() {
  const response = await fetchWithSessionToken('/api/translations');
  if (!response.ok) {
    throw new Error(`API error: ${response.status}`);
  }
  return response.json();
}

/**
 * Auto-translate some text
 */
export async function autoTranslate(payload) {
  const response = await fetchWithSessionToken('/api/translate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!response.ok) {
    throw new Error(`API error: ${response.status}`);
  }
  return response.json();
}
