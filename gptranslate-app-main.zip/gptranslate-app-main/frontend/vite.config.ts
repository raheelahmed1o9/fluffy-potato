import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import dns from 'dns';
import path from 'path';
import fs from 'fs';

dns.setDefaultResultOrder('verbatim');

export default defineConfig({
  server: {
    host: 'gptranslate-shopify.test',
    port: 5173,
    https: {
      key: fs.readFileSync('C:/Users/HP/.config/herd/config/valet/Certificates/gptranslate-shopify.test.key'),
      cert: fs.readFileSync('C:/Users/HP/.config/herd/config/valet/Certificates/gptranslate-shopify.test.crt'),
    },
    origin: 'https://gptranslate-shopify.test:5173',
    cors: false,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
      'Access-Control-Allow-Headers': '*',
    },
  },
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
});
