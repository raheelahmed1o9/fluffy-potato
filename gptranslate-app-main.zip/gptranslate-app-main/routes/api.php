<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TranslationController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\WebhookController;

// 🛡 Protect API routes using JWT verification middleware
Route::middleware(['verify.shopify.jwt'])->group(function () {
    // 📝 Translation CRUD
    Route::get('/translations', [TranslationController::class, 'index']);
    Route::post('/translations', [TranslationController::class, 'store']);
    Route::put('/translations/{id}', [TranslationController::class, 'update']);
    Route::delete('/translations/{id}', [TranslationController::class, 'destroy']);

    // 🔁 Auto-translate endpoint
    Route::post('/translate', [TranslationController::class, 'autoTranslate']);

    // 📊 Dashboard stats
    Route::get('/dashboard', [DashboardController::class, 'stats']);

    // ⚙️ Settings CRUD
    Route::get('/settings', [SettingsController::class, 'show']);
    Route::post('/settings', [SettingsController::class, 'save']);
});

// 🏪 Public route for Shopify shop info (no auth required)
Route::get('/shop', function (\Illuminate\Http\Request $request) {
    $shop = session('shop');
    $accessToken = session('access_token');

    return response()->json([
        'shop' => $shop ?? 'unknown.myshopify.com',
        'plan' => 'basic',
        'access_token' => $accessToken,
    ]);
});

// 🔔 Webhook handler (HMAC verified inside controller)
Route::post('/webhooks', [WebhookController::class, 'handle']);
