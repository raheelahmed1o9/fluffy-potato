<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\ShopifyAuthController;

// ───────────────────────────────────────────────────────────
// Shopify OAuth (must be in web.php so Herd serves HTML)
// ───────────────────────────────────────────────────────────
Route::get('/auth', [ShopifyAuthController::class, 'redirect'])
     ->name('auth.redirect');
Route::get('/auth/callback', [ShopifyAuthController::class, 'callback'])
     ->name('auth.callback');
Route::get('/auth/toplevel', [ShopifyAuthController::class, 'topLevel'])
     ->name('auth.toplevel');

// ───────────────────────────────────────────────────────────
// Catch-all: serve your built React index.html
// ───────────────────────────────────────────────────────────
Route::get('/{any}', function (Request $request) {
    return file_get_contents(public_path('index.html'));
})->where('any', '.*');
